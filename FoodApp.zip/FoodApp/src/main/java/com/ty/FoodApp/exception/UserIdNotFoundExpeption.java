package com.ty.FoodApp.exception;

public class UserIdNotFoundExpeption extends RuntimeException{
	
	private String message = "id not found";
	
	public String getMessage() {
		return message;
	}
	
	public void UserIdNotFoundException(String message) {
		this.message = message;
	}

}
