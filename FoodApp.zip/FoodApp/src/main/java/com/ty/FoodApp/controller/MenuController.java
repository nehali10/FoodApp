package com.ty.FoodApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dto.Menu;
import com.ty.FoodApp.dto.Product;
import com.ty.FoodApp.service.MenuService;

@RestController
public class MenuController {

	@Autowired
	private MenuService service;
	
	@PostMapping("/savemenu")
	public ResponseEntity<ResponseStructure<Menu>> saveMenu(@RequestBody Menu menu) {
		return service.saveMenu(menu);
	}
	
	@PutMapping("/updatemenu")
	public ResponseEntity<ResponseStructure<Menu>> updateMenu(@RequestParam int id,@RequestBody Menu menu) {
		return service.updateMenu(id, menu);
	}
	
	@DeleteMapping("/deletemenu")
	public ResponseEntity<ResponseStructure<Menu>> deleteMenu(@RequestParam int mid) {
		return service.deleteMenu(mid);
	}
	
	@GetMapping("/getbyidmenu")
	public ResponseEntity<ResponseStructure<Menu>> getMenuById(@RequestParam int mid) {
		return service.getMenuById(mid);
	}
}

















