package com.ty.FoodApp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.FoodApp.dto.Menu;
import com.ty.FoodApp.dto.Product;
import com.ty.FoodApp.repo.ProductRepo;

@Repository
public class Productdao {

	@Autowired
	private ProductRepo repo;
	
	@Autowired
	private Menudao menudao;
	
	public Product saveProduct(Product product) {
		return repo.save(product);
	}
	
	public Product updateProduct(int pid,Product product) {
		Optional<Product> product1 =  repo.findById(pid);
		if(product1.isPresent()) {
			product.setPid(pid);
			repo.save(product);
			return product1.get();
		}
		else {
			return null;
		}
	}
	
	public Product deleteProduct(int id) {
		Product product = repo.findById(id).get();
		if(product != null) {
			repo.deleteById(id);
			return product;
		}
		else {
			return null;
		}
	}


	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		Product product = repo.findById(id).get();
		if(product != null) {
			return product;
		}
		else {
			return null;
		}
	}
	
//	public List<Product> findallproduct(int mid){
//		List<Product> products = repo.findAll();
//		if(menudao != null) {
//			return products;
//		}
//		else {
//			return null;
//		}
//		
//	}
//	
}
