package com.ty.FoodApp.exception;

public class ProductIdNotFound extends RuntimeException{
	
	private String message = "id not found";
	
	public String getMessage() {
		return message;
	}
	
	public ProductIdNotFound(String message) {
		this.message = message;
	}

}
