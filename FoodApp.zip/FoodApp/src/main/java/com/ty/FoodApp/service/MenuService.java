package com.ty.FoodApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dao.Menudao;
import com.ty.FoodApp.dto.Menu;
import com.ty.FoodApp.dto.Product;
import com.ty.FoodApp.dto.User;

@Service
public class MenuService {

	@Autowired
	private Menudao menudao;
	
	public ResponseEntity<ResponseStructure<Menu>> saveMenu(Menu menu) {
		ResponseStructure<Menu>  responceStructure = new ResponseStructure<>();
		
		responceStructure.setStatus(HttpStatus.CREATED.value());
		responceStructure.setMessage("Menu scuccesfully saved");
		responceStructure.setData(menudao.saveMenu(menu));
		
		//return responceStructure;
		return new ResponseEntity<ResponseStructure<Menu>>(responceStructure,HttpStatus.CREATED);
		//return menudao.saveMenu(menu);
	}
	
	public ResponseEntity<ResponseStructure<Menu>> updateMenu(int id,Menu menu) {
		Menu menu2 = menudao.updateMenu(id,menu);
		ResponseStructure<Menu>  responceStructure = new ResponseStructure<>();
		
		if(menu2 != null) {
			//return menu;
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("Menu scuccesfully update");
			responceStructure.setData(menudao.saveMenu(menu));
			
			return new ResponseEntity<ResponseStructure<Menu>>(responceStructure,HttpStatus.OK);
			//return responceStructure;
			
		}
		else {
			return null;
		}
	}

	public ResponseEntity<ResponseStructure<Menu>> deleteMenu(int mid) {
		// TODO Auto-generated method stub
		Menu menu = menudao.deleteMenu(mid);
		ResponseStructure<Menu>  responceStructure = new ResponseStructure<>();
		
		if(menu != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("Menu scuccesfully delete");
			responceStructure.setData(menudao.saveMenu(menu));
			
			//return responceStructure;
			return new ResponseEntity<ResponseStructure<Menu>>(responceStructure,HttpStatus.OK);
			//return menu;
		}
		else {
			return null;
		}
	}

	public ResponseEntity<ResponseStructure<Menu>> getMenuById(int mid) {
		Menu menu = menudao.getMenuById(mid);
		ResponseStructure<Menu>  responceStructure = new ResponseStructure<>();
		
		if(menu != null) {
			responceStructure.setStatus(HttpStatus.FOUND.value());
			responceStructure.setMessage("Menu scuccesfully found");
			responceStructure.setData(menudao.saveMenu(menu));
			
			//return responceStructure;
			return new ResponseEntity<ResponseStructure<Menu>>(responceStructure,HttpStatus.FOUND);
			//return menu;
		}
		else {
			return null;
		}
	}
}







