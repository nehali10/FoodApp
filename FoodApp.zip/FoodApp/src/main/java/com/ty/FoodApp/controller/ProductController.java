package com.ty.FoodApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dto.Product;
import com.ty.FoodApp.dto.User;
import com.ty.FoodApp.service.ProductService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ProductController {

	@Autowired
	private ProductService service;
	
	@ApiOperation(value="Save Products",notes="API is used to save product for given product id ")
	@ApiResponses(value = {@ApiResponse(code = 200,message ="sucessfully saved"),@ApiResponse(code=400,message="id not found for the given product id")})
	
	
	@PostMapping("/saveproduct")
	public ResponseEntity<ResponseStructure<Product>> saveProduct(@RequestBody Product product) {
		return service.saveProduct(product);
	}
	
	@ApiOperation(value="Update Products",notes="API is used to update product for given product id ")
	@ApiResponses(value = {@ApiResponse(code = 200,message ="sucessfully updated"),@ApiResponse(code=400,message="id not found for the given product id")})
	
	@PutMapping("/updateProduct")
	public ResponseEntity<ResponseStructure<Product>> updateProduct(@RequestParam int id,@RequestBody Product product) {
		return service.updateProduct(id, product);
	}
	
	@ApiOperation(value="Delete Products",notes="API is used to delete product for given product id ")
	@ApiResponses(value = {@ApiResponse(code = 200,message ="sucessfully deleted"),@ApiResponse(code=400,message="id not found for the given product id")})
	
	@DeleteMapping("/deleteproduct")
	public ResponseEntity<ResponseStructure<Product>> deleteProduct(@RequestParam int id) {
		return service.deleteProduct( id);
	}
	
	@ApiOperation(value="get Products By Id",notes="API is used to get product by id for given product id ")
	@ApiResponses(value = {@ApiResponse(code = 200,message ="found product by id"),@ApiResponse(code=400,message="id not found for the given product id")})
	
	@GetMapping("/getproductbyid")
	public ResponseEntity<ResponseStructure<Product>> getProductById(@RequestParam int id) {
		return service.getProductById(id);
	}
	
	@ApiOperation(value="Get All Products ",notes="API is used to get all product ")
	@ApiResponses(value = {@ApiResponse(code = 200,message ="found all product "),@ApiResponse(code=400,message="id not found for the given product id")})
	
	@GetMapping("/getallproduct")
	public ResponseEntity<ResponseStructure<Product>> getAllProduct(@RequestParam int id) {
		return service.getProductById(id);
	}
}





















