package com.ty.FoodApp.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dao.Productdao;
import com.ty.FoodApp.dto.Product;
import com.ty.FoodApp.dto.User;

@Service
public class ProductService {

	@Autowired
	private Productdao productdao;
	
	public ResponseEntity<ResponseStructure<Product>> saveProduct(Product product) {
		//return productdao.saveProduct(product);
		ResponseStructure<Product>  responceStructure = new ResponseStructure<>();
		
		responceStructure.setStatus(HttpStatus.CREATED.value());
		responceStructure.setMessage("Product scuccesfully saved");
		responceStructure.setData(productdao.saveProduct(product));
		
		//return responceStructure;
		return new ResponseEntity<ResponseStructure<Product>>(responceStructure,HttpStatus.CREATED);
	
	}
	
	public ResponseEntity<ResponseStructure<Product>> updateProduct(int id,Product product) {
		Product product2 = productdao.updateProduct(id, product);
		ResponseStructure<Product>  responceStructure = new ResponseStructure<>();
		
		if(product2 != null) {
			//return  product;
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("product scuccesfully Updated");
			responceStructure.setData(productdao.saveProduct(product));
			
			//return responceStructure;
			return new ResponseEntity<ResponseStructure<Product>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}
	
	public ResponseEntity<ResponseStructure<Product>> deleteProduct (int id) {
		Product product = productdao.deleteProduct(id);
		ResponseStructure<Product>  responceStructure = new ResponseStructure<>();
		
		if(product != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("product scuccesfully deleted");
			responceStructure.setData(productdao.saveProduct(product));
			
			//return responceStructure;
			//return product;
			return new ResponseEntity<ResponseStructure<Product>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}

	public ResponseEntity<ResponseStructure<Product>> getProductById(int id) {
		// TODO Auto-generated method stub
		Product product = productdao.getProductById(id);
		ResponseStructure<Product>  responceStructure = new ResponseStructure<>();
		
		if(product != null) {
			responceStructure.setStatus(HttpStatus.FOUND.value());
			responceStructure.setMessage("product scuccesfully Found");
			responceStructure.setData(productdao.saveProduct(product));
			
			return new ResponseEntity<ResponseStructure<Product>>(responceStructure,HttpStatus.FOUND);
			//return responceStructure;
			//return product;
		}
		else {
			return null;
		}
	}
	
	
//	public 	ResponseEntity<ResponseStructure<List<Product>>> getAllProduct(int mid) {
//		// TODO Auto-generated method stub
//		List<Product> product = productdao.findallproduct(mid);
//		ResponseStructure<List<Product>>  responceStructure = new ResponseStructure<List<Product>>();
//		
//		if(product != null) {
//			responceStructure.setStatus(HttpStatus.OK.value());
//			responceStructure.setMessage("product scuccesfully Found");
//			responceStructure.setData(product);
//			
//			return new ResponseEntity<ResponseStructure<List<Product>>>(responceStructure,HttpStatus.OK);
//			//return responceStructure;
//			//return product;
//		}
//		else {
//			//return null;
//			throw new NoSuchElementException();
//		}
//	}
}




















