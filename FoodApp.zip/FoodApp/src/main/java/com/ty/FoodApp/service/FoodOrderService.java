package com.ty.FoodApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dao.FoodOrderdao;
import com.ty.FoodApp.dto.FoodOrder;
import com.ty.FoodApp.dto.Items;
import com.ty.FoodApp.dto.User;

@Service
public class FoodOrderService {

	@Autowired
	private FoodOrderdao foodorderdao;
	
	public ResponseEntity<ResponseStructure<FoodOrder>> saveFoodOrder(FoodOrder foodOrder) {
		
		ResponseStructure<FoodOrder>  responceStructure = new ResponseStructure<>();
		responceStructure.setStatus(HttpStatus.CREATED.value());
		responceStructure.setMessage("foodorder scuccesfully saved");
		responceStructure.setData(foodorderdao.saveFoodOrder(foodOrder));
		List<Items> list= foodOrder.getItems();
		double totalprice = 0;
		for(Items items:list) {
			totalprice += items.getCost()*items.getQuantity();
			foodOrder.setTotal_price(totalprice);
		}
		//return foodorderdao.saveFoodOrder(foodOrder);
		return new ResponseEntity<ResponseStructure<FoodOrder>>(responceStructure,HttpStatus.CREATED);
	}
	
	
	
	public ResponseEntity<ResponseStructure<FoodOrder>> updateFoodOrder(FoodOrder foodOrder,int id) {
		ResponseStructure<FoodOrder>  responceStructure = new ResponseStructure<>();
		FoodOrder FoodOrder2 = foodorderdao.getFoodOrder(id);
		responceStructure.setStatus(HttpStatus.FOUND.value());
		responceStructure.setMessage("food order scuccesfully update");
		responceStructure.setData(foodorderdao.saveFoodOrder(foodOrder));
	    if(FoodOrder2 != null) {
	    	List<Items> list= foodOrder.getItems();
			double totalprice = 0;
			for(Items items:list) {
				totalprice += items.getCost()*items.getQuantity();
				foodOrder.setTotal_price(totalprice);
			}
			//return foodorderdao.updateFoodOrder(foodOrder,id);
			return new ResponseEntity<ResponseStructure<FoodOrder>>(responceStructure,HttpStatus.FOUND);
		
	    }
	    else {
	    	return null;
	    }
	
	}
	
	public ResponseEntity<ResponseStructure<FoodOrder>> deleteFoodOrder(int id) {
		ResponseStructure<FoodOrder>  responceStructure = new ResponseStructure<>();
		FoodOrder foodOrder = foodorderdao.deleteFoodOrder(id);
		FoodOrder FoodOrder2 = foodorderdao.getFoodOrder(id);
		responceStructure.setStatus(HttpStatus.OK.value());
		responceStructure.setMessage("food order scuccesfully delete");
		responceStructure.setData(foodorderdao.saveFoodOrder(foodOrder));
	   if(foodOrder != null) {
		   //return foodOrder;
		   
		   return new ResponseEntity<ResponseStructure<FoodOrder>>(responceStructure,HttpStatus.OK);
			
	   }
	   else {
		   return null;
	   }
	
	}
}






















