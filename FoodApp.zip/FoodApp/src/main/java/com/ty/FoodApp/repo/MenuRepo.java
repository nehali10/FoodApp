package com.ty.FoodApp.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ty.FoodApp.dto.Menu;
import com.ty.FoodApp.dto.Product;

public interface MenuRepo extends JpaRepository<Menu, Integer>{

	@Query("select m from Menu m where m.mname=?1")
	public List<Product> findallproduct(Menu menu);
}