package com.ty.FoodApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dao.Itemdao;
import com.ty.FoodApp.dto.Items;
import com.ty.FoodApp.dto.User;

@Service
public class ItemsService {

	@Autowired
	private Itemdao itemsdao;
	
	public ResponseEntity<ResponseStructure<Items>> saveItems(Items items) {
		ResponseStructure<Items>  responceStructure = new ResponseStructure<>();
		
		responceStructure.setStatus(HttpStatus.CREATED.value());
		responceStructure.setMessage("items scuccesfully saved");
		responceStructure.setData(itemsdao.saveItems(items));
		
		return new ResponseEntity<ResponseStructure<Items>>(responceStructure,HttpStatus.CREATED);
		//return responceStructure;
		//return itemsdao.saveItems(items);
	}
	public ResponseEntity<ResponseStructure<Items>> updateItems(Items items,int id) {
		Items items2 = itemsdao.updateItems(items,id);
		ResponseStructure<Items>  responceStructure = new ResponseStructure<>();
		
		if(items2 != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("items scuccesfully updated");
			responceStructure.setData(itemsdao.saveItems(items));
			
			//return responceStructure;
			//return items;
			return new ResponseEntity<ResponseStructure<Items>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}
//	public ResponseStructure<Items> deleteItems(int id) {
//		Items items2 = itemsdao.deleteItems(id);
//		ResponseStructure<Items>  responceStructure = new ResponseStructure<>();
//		
//		if(items2 != null) {
//			responceStructure.setStatus(HttpStatus.OK.value());
//			responceStructure.setMessage("items scuccesfully deleted");
//			responceStructure.setData(itemsdao.saveItems(items));
//			
//			return responceStructure;
//			//return items;
//		}
//		else {
//			return null;
//		}
//	}
	public ResponseEntity<ResponseStructure<Items>> deleteItems(int id) {
		Items items = itemsdao.deleteItems(id);
		ResponseStructure<Items>  responceStructure = new ResponseStructure<>();
		
		if(items != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("items scuccesfully deleted");
			responceStructure.setData(itemsdao.saveItems(items));
			
			//return responceStructure;
			//return items;
			return new ResponseEntity<ResponseStructure<Items>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}
	
	public ResponseEntity<ResponseStructure<Items>> getItemsById(int id) {
		Items items = itemsdao.getItemsById(id);
		ResponseStructure<Items>  responceStructure = new ResponseStructure<>();
		
		if(items != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("items scuccesfully found");
			responceStructure.setData(itemsdao.saveItems(items));
			
			//return responceStructure;
			//return items;
			return new ResponseEntity<ResponseStructure<Items>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}
	
	
}












