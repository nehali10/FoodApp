package com.ty.FoodApp.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.FoodApp.config.ResponseStructure;
import com.ty.FoodApp.dao.UserDao;
import com.ty.FoodApp.dto.User;

@Service
public class UserService {

	@Autowired
	private UserDao dao;
	
	public ResponseEntity<ResponseStructure<User>> saveUser(User user) {
		ResponseStructure<User>  responceStructure = new ResponseStructure<>();
		responceStructure.setStatus(HttpStatus.CREATED.value());
		responceStructure.setMessage("user scuccesfully saved");
		responceStructure.setData(dao.SaveUser(user));
		
		return new ResponseEntity<ResponseStructure<User>>(responceStructure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<User>> updateUser(int id,User user) {
		User user2 = dao.updateUser(id, user);
		ResponseStructure<User> responceStructure = new ResponseStructure<>();
		
		if(user2 != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("user succesfully updated");
			responceStructure.setData(user);
			//return responceStructure;
			return new ResponseEntity<ResponseStructure<User>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}
	public ResponseEntity<ResponseStructure<User>> deleteUser(int id) {
		User user = dao.deleteUser(id);
		ResponseStructure<User> responceStructure = new ResponseStructure<>();
		
		if(user != null) {
			responceStructure.setStatus(HttpStatus.OK.value());
			responceStructure.setMessage("user succesfully deleted");
			responceStructure.setData(user);
			//return responceStructure;
			//return user;
			return new ResponseEntity<ResponseStructure<User>>(responceStructure,HttpStatus.OK);
		}
		else {
			return null;
		}
	}
	
	public ResponseEntity<ResponseStructure<User>> getUserById(int id) {
		User user = dao.getUserById(id);
		ResponseStructure<User> responceStructure = new ResponseStructure<>();
		
		if(user != null) {
			responceStructure.setStatus(HttpStatus.FOUND.value());
			responceStructure.setMessage("user succesfully found");
			responceStructure.setData(user);
			//return responceStructure;
			//return user;
			return new ResponseEntity<ResponseStructure<User>>(responceStructure,HttpStatus.FOUND);
		}
		else {
			//return null;
			throw new NoSuchElementException();
		}
	}
}

















