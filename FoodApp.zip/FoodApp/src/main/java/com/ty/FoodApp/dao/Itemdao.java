package com.ty.FoodApp.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.FoodApp.dto.Items;
import com.ty.FoodApp.repo.ItemsRepo;

@Repository
public class Itemdao {

	
	@Autowired
	private ItemsRepo repo;
	
	public Items saveItems(Items items) {
		return repo.save(items);
	}

	public Items updateItems(Items items,int id) {
		
		Items items2 = repo.findById(id).get();
		if(items2 != null) {
			items.setItem_id(id);
			return repo.save(items);
		}
		else {
			return null;
		}
	}
	
   public Items deleteItems(int id) {
		
		Items items = repo.findById(id).get();
		if(items != null) {
			items.setItem_id(id);
			return repo.save(items);
		}
		else {
			return null;
		}
	}
   
   public Items getItemsById(int id) {
		
		Items items = repo.findById(id).get();
		if(items != null) {
			
			return items;
		}
		else {
			return null;
		}
	}

	
}
